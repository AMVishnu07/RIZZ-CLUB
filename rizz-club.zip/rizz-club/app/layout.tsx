import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Rizz Club — Your unofficial wingman', description: 'Find your words. Keep your personality.', icons: { icon: '/icon.svg' } };
export default function Layout({ children }: {children: React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
