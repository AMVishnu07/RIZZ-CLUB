import { env } from 'cloudflare:workers';
import { handleWingman } from '@/lib/wingman.mjs';
export const dynamic = 'force-dynamic';
function handle(request: Request) {
  const secrets=env as typeof env & { OPENAI_API_KEY?: string; OPENAI_MODEL?: string };
  return handleWingman(request, {
    apiKey: secrets.OPENAI_API_KEY,
    model: secrets.OPENAI_MODEL || 'gpt-6-luna',
    userId: request.headers.get('oai-authenticated-user-id'),
  });
}
export const GET=handle;
export const POST=handle;
