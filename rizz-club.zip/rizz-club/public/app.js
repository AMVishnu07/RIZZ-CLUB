'use strict';

const icons = {
  'arrow-up-right':'<path d="M6 18 18 6M6 6h12v12"/>',
  'arrow-right':'<path d="M4 12h16m-6-6 6 6-6 6"/>',
  'arrow-up':'<path d="M12 20V4m-6 6 6-6 6 6"/>',
  volume:'<path d="M11 5 6 9H3v6h3l5 4V5zM16 9l5 6m0-6-5 6"/>',
  'volume-on':'<path d="M11 5 6 9H3v6h3l5 4V5zM15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
  copy:'<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M15 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3"/>',
  bookmark:'<path d="M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16l-6-4-6 4z"/>',
  shuffle:'<path d="M3 6h3c6 0 6 12 12 12h3m-4-4 4 4-4 4M3 18h3c2 0 3-1 4-3m4-6c1-2 2-3 4-3h3m-4-4 4 4-4 4"/>',
  sparkles:'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3zM20 2v4m-2-2h4"/>',
  message:'<path d="M21 11a8 8 0 0 1-8 8H5l-3 3V11a9 9 0 0 1 19 0z"/><path d="M7 11h.01M12 11h.01M17 11h.01"/>',
  play:'<path d="m8 4 12 8-12 8V4z"/>',
  lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v3"/>',
  trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>'
};
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function icon(name){return `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${icons[name] || icons.sparkles}</svg>`;}
function renderIcons(root=document){root.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=icon(el.dataset.icon);});}
function el(tag,cls,txt){const n=document.createElement(tag);if(cls)n.className=cls;if(txt!==undefined)n.textContent=txt;return n;}
let toastTimer;
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),2600);}
async function copyText(value){try{await navigator.clipboard.writeText(value);toast('Copied. Give it your own little twist.');}catch{const input=el('textarea','sr-only');input.value=value;document.body.append(input);input.select();let success=false;try{success=document.execCommand('copy');}catch{}input.remove();toast(success?'Copied to clipboard.':'Copy unavailable. Select the text to copy it.');}}

const openers=window.RIZZ_OPENERS;
let vibe='smooth',lineIndex=0;
const lineDecks={};
function takeLine(style){let deck=lineDecks[style];if(!deck?.length){deck=Array.from({length:openers[style].length},(_,i)=>i);for(let i=deck.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}if(deck[deck.length-1]===lineIndex&&deck.length>1)[deck[0],deck[deck.length-1]]=[deck[deck.length-1],deck[0]];lineDecks[style]=deck;}return deck.pop();}
lineDecks.smooth=Array.from({length:openers.smooth.length-1},(_,i)=>i+1).sort(()=>Math.random()-.5);
let saved=[];
try{const value=JSON.parse(localStorage.getItem('rizzclub.saved.v1')||'[]');if(Array.isArray(value))saved=value.filter(x=>x&&typeof x.text==='string'&&typeof x.kind==='string'&&x.text.length<=2000).slice(0,100);}catch{}
function persistSaved(){try{localStorage.setItem('rizzclub.saved.v1',JSON.stringify(saved));return true;}catch{toast('Device storage is unavailable. Saved for this visit only.');return false;}}
function isSaved(text){return saved.some(s=>s.text===text);}
function bookmarkButton(text,kind){const b=el('button','icon-button');b.innerHTML=icon('bookmark');b.dataset.bookmarkText=text;b.setAttribute('aria-label',isSaved(text)?'Unsave reply':'Save reply');b.setAttribute('aria-pressed',String(isSaved(text)));b.addEventListener('click',()=>toggleSave(text,kind));return b;}
function copyButton(text){const b=el('button','icon-button');b.innerHTML=icon('copy');b.setAttribute('aria-label','Copy text');b.addEventListener('click',()=>copyText(text));return b;}
function refreshSaveButtons(){ $('#saved-count').textContent=saved.length; $('#saved-total').textContent=saved.length;const current=openers[vibe][lineIndex][0];$('#save-line').setAttribute('aria-pressed',String(isSaved(current)));$('#save-line').setAttribute('aria-label',isSaved(current)?'Unsave opening line':'Save opening line');$$('[data-bookmark-text]').forEach(b=>{const yes=isSaved(b.dataset.bookmarkText);b.setAttribute('aria-pressed',String(yes));b.setAttribute('aria-label',yes?'Unsave reply':'Save reply');});}
function toggleSave(text,kind){if(isSaved(text)){saved=saved.filter(s=>s.text!==text);if(persistSaved())toast('Removed from your saved ideas.');}else{if(saved.length>=100){toast('Your book is full. Remove an idea to save another.');return;}saved.unshift({text,kind,date:Date.now()});if(persistSaved())toast('Saved to your little black book.');}refreshSaveButtons();if(location.hash==='#saved')renderSaved();}
function renderLine(){const [text,hint]=openers[vibe][lineIndex];$('#current-line').textContent=text;$('#line-hint').textContent=hint;refreshSaveButtons();$('#line-counter').textContent=`${openers[vibe].length-(lineDecks[vibe]?.length??openers[vibe].length)} of ${openers[vibe].length} ${vibe} lines explored`;}
function nextLine(){lineIndex=takeLine(vibe);renderLine();if(soundEnabled)playSound('sparkle',false,.35);}
$$('[data-vibe]').forEach(b=>b.addEventListener('click',()=>{vibe=b.dataset.vibe;lineIndex=takeLine(vibe);$$('[data-vibe]').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',String(x===b));});renderLine();}));
$('#generate-line').addEventListener('click',nextLine);
$('#copy-line').addEventListener('click',()=>copyText(openers[vibe][lineIndex][0]));
$('#save-line').addEventListener('click',()=>toggleSave(openers[vibe][lineIndex][0],`${vibe} opener`));
// Local starter sets: usable immediately, clearly separate from live AI replies.
function mountQuickLines(root){
  const lines=window.RIZZ_QUICK_OPENERS;
  let deck=Array.from({length:lines.length},(_,i)=>i).reverse(),previous=[];
  const list=el('div','quick-line-list');list.setAttribute('aria-live','polite');list.setAttribute('aria-atomic','true');
  const footer=el('div','quick-line-footer');
  const more=el('button','quick-more');more.type='button';more.innerHTML=icon('shuffle');more.append(el('span','','More lines'));
  footer.append(el('span','','Handpicked · ready without AI'),more);root.replaceChildren(list,footer);
  function draw(){
    if(deck.length<3){
      const shuffle=values=>{for(let i=values.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[values[i],values[j]]=[values[j],values[i]];}return values;};
      // Keep the immediately previous set out of the first draw of the next cycle.
      deck=[...shuffle([...previous]),...shuffle(lines.map((_,i)=>i).filter(i=>!previous.includes(i)))];
    }
    previous=[deck.pop(),deck.pop(),deck.pop()];list.replaceChildren();
    previous.forEach(i=>{const [label,text]=lines[i];const card=el('article','quick-line');
      const detail=el('div','quick-line-detail');detail.append(el('span','quick-line-label',label),el('p','',text));
      const actions=el('div','quick-line-actions');const copy=copyButton(text);copy.classList.add('quick-copy');copy.append(el('span','','Copy'));copy.setAttribute('aria-label',`Copy ${label.toLowerCase()} pickup line`);
      const save=bookmarkButton(text,'Quick opener');actions.append(copy,save);card.append(detail,actions);list.append(card);
    });
  }
  more.addEventListener('click',draw);draw();
}
function renderSaved(){const root=$('#saved-list');root.replaceChildren();refreshSaveButtons();$('#clear-saved').disabled=!saved.length;if(!saved.length){const state=el('div','empty-state');state.append(el('div','empty-icon','♡'),el('h2','','A good line is worth keeping.'),el('p','','Tap the bookmark beside an opener or a reply. Your favourites will be waiting right here.'));const link=el('a','button button-dark','Find an opening line ↗');link.href='#lab';state.append(link);root.append(state);return;}saved.forEach(item=>{const card=el('article','saved-card');card.append(el('span','reply-label',item.kind.toUpperCase()),el('p','',item.text));const foot=el('div','reply-footer');foot.append(el('span','','Make it your own.'));const actions=el('div');actions.append(copyButton(item.text),bookmarkButton(item.text,item.kind));foot.append(actions);card.append(foot);root.append(card);});}
$('#clear-saved').addEventListener('click',()=>{if(!saved.length)return;if(window.confirm('Remove all saved lines and replies from this device?')){saved=[];persistSaved();renderSaved();toast('Your saved ideas have been cleared.');}});

// Original synthesized effects; no downloaded or copyrighted meme recordings.
let audioContext=null,soundEnabled=false,soundTimers=[],activeAudio=[];
function setSound(enabled){soundEnabled=enabled;$('#sound-toggle').setAttribute('aria-pressed',String(enabled));$('#sound-status').textContent=enabled?'Sound on':'Sound off';$('#sound-toggle [data-icon]').innerHTML=icon(enabled?'volume-on':'volume');if(!enabled){activeAudio.forEach(n=>{try{n.stop();}catch{}});activeAudio=[];soundTimers.forEach(clearTimeout);soundTimers=[];$$('.sound-pad').forEach(b=>{b.classList.remove('playing');b.setAttribute('aria-pressed','false');});}}
async function audioReady(){const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio){toast('Sound effects are not supported by this browser.');return false;}try{if(!audioContext)audioContext=new Audio();await audioContext.resume();return audioContext.state==='running';}catch{toast('Your browser could not enable audio. Try again.');return false;}}
function tone(freq,start,duration,type='sine',level=.09,endFreq){const o=audioContext.createOscillator(),g=audioContext.createGain();o.type=type;o.frequency.setValueAtTime(freq,start);if(endFreq)o.frequency.exponentialRampToValueAtTime(endFreq,start+duration);g.gain.setValueAtTime(0,start);g.gain.linearRampToValueAtTime(level,start+.015);g.gain.exponentialRampToValueAtTime(.001,start+duration);o.connect(g);g.connect(audioContext.destination);o.start(start);o.stop(start+duration+.04);activeAudio.push(o);o.onended=()=>{o.disconnect();g.disconnect();activeAudio=activeAudio.filter(n=>n!==o);};}
async function playSound(name,explicit=true,scale=1){if(explicit){if(!await audioReady())return;setSound(true);}else if(!soundEnabled||!audioContext)return;const now=audioContext.currentTime+.02;let duration=1000;if(name==='sparkle'){[523.25,659.25,783.99,1046.5].forEach((n,i)=>tone(n,now+i*.09,.35,'sine',.09*scale));duration=800;}else if(name==='bruh'){tone(155,now,.58,'triangle',.15*scale,48);tone(77,now,.5,'sine',.13*scale,38);duration=800;}else if(name==='violin'){[440,415.3,392,369.99].forEach((n,i)=>{tone(n,now+i*.28,.36,'triangle',.09*scale);tone(n*2,now+i*.28,.31,'sine',.018*scale);});duration=1400;}else if(name==='win'){[392,523.25,659.25,783.99].forEach((n,i)=>tone(n,now+i*.12,.25,'triangle',.09*scale));[523.25,659.25,783.99].forEach(n=>tone(n,now+.52,.5,'sine',.05*scale));duration=1200;}const b=$(`[data-sound="${name}"]`);if(b){b.classList.add('playing');b.setAttribute('aria-pressed','true');soundTimers.push(setTimeout(()=>{b.classList.remove('playing');b.setAttribute('aria-pressed','false');},duration));}}
$('#sound-toggle').addEventListener('click',async()=>{if(soundEnabled)setSound(false);else if(await audioReady()){setSound(true);playSound('sparkle',false,.45);}});
$$('[data-sound]').forEach(b=>{b.setAttribute('aria-pressed','false');b.addEventListener('click',()=>playSound(b.dataset.sound));});

// The chat requests fresh model responses from the server. It has no canned fallback.
let chatHistory=[],shownReplies=[],inFlight=false,requestController=null,requestSerial=0;
function trimHistory(){while(chatHistory.length>16||chatHistory.reduce((n,m)=>n+m.content.length,0)>22000)chatHistory.splice(0,2);}
function assistantShell(){const wrap=el('div','message assistant-message');wrap.append(el('span','wingman-avatar','✳'));const body=el('div','message-body');body.append(el('div','message-author','WINGMAN'));wrap.append(body);return {wrap,body};}
function welcome(){
  const root=$('#chat-messages');root.replaceChildren();const {wrap,body}=assistantShell();
  body.append(el('h2','message-heading','Start with a little spark.'),el('p','message-copy',"Need a first text? Try one of these quick openers. Already talking? Paste the exchange below for a reply that fits."));
  const quick=el('div','quick-start chat-quick-start');body.append(quick);mountQuickLines(quick);root.append(wrap);chatHistory=[];shownReplies=[];
}
function scrollChat(){const root=$('#chat-messages');root.scrollTop=root.scrollHeight;}
async function checkConnection(){try{const r=await fetch('/api/wingman',{cache:'no-store'});const data=await r.json();if(data.configured){$('#bot-status').textContent='AI connection configured. Paste the exchange to get fresh replies.';$('#bot-status').className='bot-status ready';$('#chat-mode').textContent='LIVE AI';}else{$('#bot-status').textContent='Live AI setup is pending. Wingman needs the owner’s OpenAI connection before it can generate replies.';$('#bot-status').className='bot-status';$('#chat-mode').textContent='AI SETUP';}}catch{$('#bot-status').textContent='The AI connection could not be checked. Try sending a message to check again.';$('#bot-status').className='bot-status error';}}
function renderReply(result){const {wrap,body}=assistantShell();body.append(el('p','message-copy',result.context));result.replies.forEach((option,index)=>{const card=el('div','reply-option');card.append(el('div','reply-label',(index===0?'✦ ':'')+option.label.toUpperCase()),el('p','reply-text',option.text));const foot=el('div','reply-footer');foot.append(el('span','',option.why));const actions=el('div');actions.append(copyButton(option.text),bookmarkButton(option.text,'Wingman reply'));foot.append(actions);card.append(foot);body.append(card);});if(result.tip)body.append(el('p','reply-tip',result.tip));if(result.replies.length){const actions=el('div','reply-actions');[['Fresh angle','Give me three new replies to the same exchange. Use genuinely different ideas, not rewordings of the last set.'],['Shorter','Make the replies to the same exchange shorter.'],['Smoother','Make the replies to the same exchange smoother and less cheesy.']].forEach(([label,prompt])=>{const b=el('button','',label);b.addEventListener('click',()=>sendMessage(prompt));actions.append(b);});body.append(actions);}return wrap;}
function setBusy(busy){inFlight=busy;$('#chat-form button[type=submit]').disabled=busy;$('#chat-form button[type=submit]').setAttribute('aria-label',busy?'Writing reply ideas':'Get reply ideas');$$('.reply-actions button,.retry-button').forEach(b=>b.disabled=busy);$('#chat-messages').setAttribute('aria-busy',String(busy));}
async function sendMessage(value,retry=false){const text=value.trim().slice(0,4000);if(!text||inFlight)return;const serial=++requestSerial;const root=$('#chat-messages');if(!retry)root.append(el('div','message user-message',text));const {wrap:loading,body}=assistantShell();const typing=el('div','typing-indicator');typing.innerHTML='<i></i><i></i><i></i>';typing.append(el('span','','Finding your next move…'));body.append(typing);root.append(loading);setBusy(true);$('#chat-input').value='';$('#char-count').textContent='0 / 4000';scrollChat();const controller=new AbortController();requestController=controller;const timer=setTimeout(()=>controller.abort(),40000);try{trimHistory();const response=await fetch('/api/wingman',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,history:chatHistory,tone:$('#reply-tone').value,language:$('#reply-language').value,avoid:shownReplies.slice(-36)}),signal:controller.signal});let data;try{data=await response.json();}catch{throw new Error('The server returned an unreadable response. Please try again.');}if(serial!==requestSerial)return;if(!response.ok){if(data.code==='AI_NOT_CONFIGURED'){$('#bot-status').textContent='Live AI setup is pending. The owner needs to finish the OpenAI connection.';$('#bot-status').className='bot-status';$('#chat-mode').textContent='AI SETUP';}if(data.code==='SIGN_IN_REQUIRED'){const error=new Error(data.error);error.signIn=true;throw error;}throw new Error(data.error||'The reply could not be generated. Please try again.');}if(!data.result||!Array.isArray(data.result.replies))throw new Error('The reply did not arrive correctly. Please try again.');loading.replaceWith(renderReply(data.result));chatHistory.push({role:'user',content:text},{role:'assistant',content:JSON.stringify(data.result)});shownReplies.push(...data.result.replies.map(r=>r.text));shownReplies=shownReplies.slice(-60);trimHistory();$('#bot-status').textContent='AI connected. This conversation’s recent messages shape each reply.';$('#bot-status').className='bot-status ready';$('#chat-mode').textContent='LIVE AI';}catch(error){if(serial!==requestSerial)return;const {wrap,body:errBody}=assistantShell();const message=error.name==='AbortError'?'That took too long. Your message is here—try again when ready.':error.message;errBody.append(el('p','chat-error',message));if(error.signIn){const link=el('a','button button-light','Sign in with ChatGPT');link.href='/signin-with-chatgpt?return_to=%2F%23wingman';link.target='_top';errBody.append(link);}else{const button=el('button','retry-button','Try again');button.addEventListener('click',()=>{if(inFlight)return;wrap.remove();sendMessage(text,true);});errBody.append(button);}loading.replaceWith(wrap);}finally{clearTimeout(timer);if(serial===requestSerial){setBusy(false);requestController=null;scrollChat();}}}
$('#chat-form').addEventListener('submit',e=>{e.preventDefault();sendMessage($('#chat-input').value);});
$('#chat-input').addEventListener('input',e=>{$('#char-count').textContent=`${e.target.value.length} / 4000`;});
$('#chat-input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();sendMessage(e.target.value);}});
$('#clear-chat').addEventListener('click',()=>{requestSerial++;requestController?.abort();requestController=null;setBusy(false);welcome();$('#chat-input').value='';$('#char-count').textContent='0 / 4000';toast('Fresh chat. Previous context cleared.');});
function route(){let name=location.hash.slice(1);if(!['lab','wingman','saved'].includes(name))name='lab';const previous=document.body.dataset.view;$$('.view').forEach(view=>view.classList.toggle('hidden',view.id!==name+'-view'));$$('[data-route]').forEach(a=>{a.classList.toggle('active',a.dataset.route===name);if(a.dataset.route===name)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});document.body.dataset.view=name;document.title=`${name==='wingman'?'Your Wingman':name==='saved'?'Saved Ideas':'Your unofficial wingman'} — Rizz Club`;if(name==='saved')renderSaved();if(name==='wingman')checkConnection();if(previous!==name)window.scrollTo({top:0,behavior:'instant'});}
window.addEventListener('hashchange',route);
$('#find-line').addEventListener('click',()=>{$('#line-studio').scrollIntoView({behavior:'smooth',block:'center'});$('#generate-line').focus({preventScroll:true});});
window.addEventListener('storage',event=>{if(event.key==='rizzclub.saved.v1'){try{const data=JSON.parse(event.newValue||'[]');saved=Array.isArray(data)?data.filter(x=>x&&typeof x.text==='string'&&typeof x.kind==='string'&&x.text.length<=2000).slice(0,100):[];}catch{saved=[];}refreshSaveButtons();if(location.hash==='#saved')renderSaved();}});
renderIcons();renderLine();mountQuickLines($('#home-quick-lines'));welcome();route();
